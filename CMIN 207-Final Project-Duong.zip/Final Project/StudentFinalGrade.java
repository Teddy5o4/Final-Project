import java.io.*;  // Import class for file input.
import java.util.Scanner; // Import class for scanner

public class StudentFinalGrade 
{
	public static void main(String args[]) 
	{
 		// Declare variables
		int arraySize = 100;
		String inputFromFile = "";
		boolean eof = false;
		String[] studentName = new String[arraySize];
		double[] firstTest = new double[arraySize];
		double[] secondTest = new double[arraySize];
		double[] thirdTest = new double[arraySize];
		double[] finalTest = new double[arraySize];
		String[] finalGrade = new String[arraySize];
		double[] totalScore = new double[arraySize];
		int numOfStudents = 0;
		
		double FIRST_TW = 0.20; // The weight of the first test towards the final.
		double SECOND_TW = 0.20; // The weight of the second test towards the final.
		double THIRD_TW = 0.20; // The weight of the third test towards the final.
		double FINAL_TW = 0.40; // The weight of the final test towards the final.

		// Create file object and file reader objects.
      	try (
        	  FileReader inputFile = new FileReader("Data File.Dat");
        	  BufferedReader inputBuff = new BufferedReader(inputFile))
        	  {
		    // Write while loop that reads records from file until EOF is reached.  
          	    while (!eof) {
            	inputFromFile = inputBuff.readLine(); // Read the name
            	if (inputFromFile == null) { // Read the first line
              	  eof = true; // If there is no name, then exit the loop
            	} // End if
			else { // If there is a name, read the test scores
			  studentName[numOfStudents] = inputFromFile;
			  firstTest[numOfStudents] = Double.parseDouble(inputBuff.readLine()); // Read the first test score
			  secondTest[numOfStudents] = Double.parseDouble(inputBuff.readLine()); // Read the second test score
			  thirdTest[numOfStudents] = Double.parseDouble(inputBuff.readLine()); // Read the third test score
			  finalTest[numOfStudents] = Double.parseDouble(inputBuff.readLine()); // Read the final test score
			  totalScore[numOfStudents] = 0.0; // Initialize totalScore[] array
			  finalGrade[numOfStudents] = ""; // Initialize finalGrade[] array
			  numOfStudents = numOfStudents + 1;
			} // End else if	
		    } // End while
			
		 CalculateGrade student[] = new CalculateGrade[numOfStudents]; // Create an array object of the CalculateGrade class to set the name, scores, 
		 									         // and calculate the final grade.
           	 for (int i = 0; i <= numOfStudents - 1; i++) {
		   student[i] = new CalculateGrade(studentName[i], firstTest[i], secondTest[i], thirdTest[i], finalTest[i], totalScore[i]);
		   totalScore[i] = student[i].calcFinalScore(FIRST_TW, SECOND_TW, THIRD_TW, FINAL_TW);
		   finalGrade[i] = student[i].calcFinalGrade();
		   System.out.println(student[i].getStudentName() + " has a total score of " + totalScore[i] + 
				" with a final grade of " + finalGrade[i]);
		 } // End while 		
		  
          	inputBuff.close();
		} // End try
        	catch (IOException e) { 
            	System.out.println("Error -- " + e.toString());
        	}   
    
		System.exit(0);

	} // End of main() method.

} // End of StudentFinalGrade class.