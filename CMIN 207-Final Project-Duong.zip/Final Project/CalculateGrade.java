public class CalculateGrade {

	private String studentName;
	private double firstTestScore;
	private double secondTestScore;
	private double thirdTestScore;
	private double finalTestScore;
	private double totalScore;

	// Constructor with five parameters from the program
	public CalculateGrade(String studentName, double firstTestScore, double secondTestScore, double thirdTestScore, double finalTestScore , double totalScore) {
		setStudentName(studentName);
		setTestScore(firstTestScore, secondTestScore, thirdTestScore, finalTestScore);
		this.totalScore = totalScore;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	} // End setStudentName() method

	public void setTestScore(double firstTestScore, double secondTestScore, double thirdTestScore, double finalTestScore) {
		this.firstTestScore = firstTestScore;
		this.secondTestScore = secondTestScore;
		this.thirdTestScore = thirdTestScore;
		this.finalTestScore = finalTestScore;
	} // End setFirstTestScore() method

	public String getStudentName() {
		return studentName;
	} // End getStudentName() method

	public double getFirstTestScore() {
		return firstTestScore;
	} // End getFirstTestScore() method

	public double getSecondTestScore() {
		return secondTestScore;
	} // End getSecondTestScore() method

	public double getThirdTestScore() {
		return thirdTestScore;
	} // End getThirdTestScore() method

	public double getFinalTestScore() {
		return finalTestScore;
	} // End getFinalTestScore() method

	public double calcFinalScore(double FIRST_TW, double SECOND_TW, double THIRD_TW, double FINAL_TW) {
		this.totalScore = (firstTestScore * FIRST_TW) + (secondTestScore * SECOND_TW) + (thirdTestScore * THIRD_TW) + (finalTestScore * FINAL_TW);
		return this.totalScore;
	}

	public String calcFinalGrade() {
		String finalGrade = " ";
		if (this.totalScore >= 90) { // Assign letter grade
		  finalGrade = "A";
		}
		else if (this.totalScore < 90 && totalScore >= 80) {
		  finalGrade = "B";
		}		
		else if (this.totalScore < 80 && totalScore >= 70) {
		  finalGrade = "C";
		}		
		else if (this.totalScore < 70 && totalScore >= 60) {
		  finalGrade = "D";
		}
		else if (this.totalScore < 60) {
		  finalGrade = "F";
		}
		return finalGrade;
	}

} // End CalculateGrade class